package com.mbbs.vpnstudent

import com.google.firebase.firestore.FirebaseFirestore
import com.mbbs.vpnstudent.model.ServerConfig
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

class ServerRepository {
    private val db = FirebaseFirestore.getInstance()

    /** Live list of servers - updates instantly in the app whenever the admin
     *  panel adds, edits, enables/disables, or deletes a server. No app update needed. */
    fun listenServers(): Flow<List<ServerConfig>> = callbackFlow {
        val reg = db.collection("servers")
            .whereEqualTo("isEnabled", true)
            .addSnapshotListener { snapshot, _ ->
                val list = snapshot?.documents?.mapNotNull { doc ->
                    doc.toObject(ServerConfig::class.java)?.apply { id = doc.id }
                } ?: emptyList()
                trySend(list)
            }
        awaitClose { reg.remove() }
    }

    /** Global app settings the admin controls remotely: e.g. turn ads on/off,
     *  force-update message, maintenance mode. Document: settings/app */
    fun listenAppSettings(onChange: (AppSettings) -> Unit) {
        db.collection("settings").document("app")
            .addSnapshotListener { snap, _ ->
                val s = AppSettings(
                    adsEnabled = snap?.getBoolean("adsEnabled") ?: true,
                    interstitialEveryNConnects = (snap?.getLong("interstitialEveryNConnects") ?: 3L).toInt(),
                    maintenanceMode = snap?.getBoolean("maintenanceMode") ?: false,
                    announcement = snap?.getString("announcement") ?: ""
                )
                onChange(s)
            }
    }

    /** Anonymous usage ping so the admin panel can show live connected-user counts. */
    fun reportConnection(serverId: String, connected: Boolean) {
        db.collection("activeSessions").document(serverId).let { ref ->
            db.runTransaction { tx ->
                val current = tx.get(ref).getLong("count") ?: 0L
                val next = if (connected) current + 1 else maxOf(0, current - 1)
                tx.set(ref, mapOf("count" to next, "serverId" to serverId))
            }
        }
    }
}

data class AppSettings(
    val adsEnabled: Boolean = true,
    val interstitialEveryNConnects: Int = 3,
    val maintenanceMode: Boolean = false,
    val announcement: String = ""
)
