package com.mbbs.vpnstudent

import android.app.Application
import com.google.android.gms.ads.MobileAds
import com.google.firebase.FirebaseApp

class VpnApp : Application() {
    override fun onCreate() {
        super.onCreate()
        FirebaseApp.initializeApp(this)
        // Initialize AdMob SDK once at app start
        MobileAds.initialize(this) {}
    }
}
