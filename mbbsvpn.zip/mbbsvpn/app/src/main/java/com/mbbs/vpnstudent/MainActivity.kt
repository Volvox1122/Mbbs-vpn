package com.mbbs.vpnstudent

import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.mbbs.vpnstudent.databinding.ActivityMainBinding
import com.mbbs.vpnstudent.model.ServerConfig
import com.mbbs.vpnstudent.vpn.VpnManager
import com.wireguard.android.backend.GoBackend
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val repo = ServerRepository()
    private lateinit var adapter: ServerAdapter
    private var pendingServer: ServerConfig? = null
    private var interstitialAd: InterstitialAd? = null
    private var connectCount = 0
    private var settings = AppSettings()

    // Handles the "This app wants to create a VPN connection" system dialog
    private val vpnPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            pendingServer?.let { doConnect(it) }
        } else {
            Toast.makeText(this, "VPN permission is required to connect", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        VpnManager.init(applicationContext)

        adapter = ServerAdapter { server -> onServerSelected(server) }
        binding.serverList.layoutManager = LinearLayoutManager(this)
        binding.serverList.adapter = adapter

        binding.btnStudyTools.setOnClickListener {
            startActivity(Intent(this, StudyToolsActivity::class.java))
        }

        binding.btnDisconnect.setOnClickListener {
            VpnManager.disconnect()
            updateStatus(false)
        }

        repo.listenAppSettings { s ->
            settings = s
            if (s.adsEnabled) loadInterstitial()
            if (s.maintenanceMode) {
                Toast.makeText(this, "Server under maintenance, try again soon", Toast.LENGTH_LONG).show()
            }
        }

        lifecycleScope.launch {
            repo.listenServers().collect { servers ->
                adapter.submitList(servers)
                binding.emptyState.visibility =
                    if (servers.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
            }
        }

        binding.adBanner.loadAd(AdRequest.Builder().build())
        updateStatus(VpnManager.isConnected())
    }

    private fun onServerSelected(server: ServerConfig) {
        pendingServer = server
        val intent = VpnService.prepare(this)
        if (intent != null) {
            vpnPermissionLauncher.launch(intent)
        } else {
            doConnect(server)
        }
    }

    private fun doConnect(server: ServerConfig) {
        val ok = VpnManager.connect(server)
        updateStatus(ok)
        if (ok) {
            repo.reportConnection(server.id, true)
            connectCount++
            if (settings.adsEnabled && connectCount % settings.interstitialEveryNConnects == 0) {
                interstitialAd?.show(this)
            }
            Toast.makeText(this, "Connected to ${server.name}", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Connection failed, try another server", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateStatus(connected: Boolean) {
        binding.statusText.text = if (connected) "Connected" else "Not connected"
        binding.btnDisconnect.isEnabled = connected
    }

    private fun loadInterstitial() {
        InterstitialAd.load(
            this,
            "ca-app-pub-3940256099942544/1033173712", // TEST ad unit id - replace with your own
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                }
            }
        )
    }
}
