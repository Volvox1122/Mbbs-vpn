package com.mbbs.vpnstudent.model

/**
 * One document in the Firestore "servers" collection = one VPN server.
 * The admin panel writes these fields; the app reads them.
 */
data class ServerConfig(
    var id: String = "",
    var name: String = "",           // e.g. "Germany - Frankfurt"
    var countryCode: String = "",    // e.g. "DE" (used to show flag)
    var endpointHost: String = "",   // server public IP or domain
    var endpointPort: Int = 51820,
    var serverPublicKey: String = "",
    var clientPrivateKey: String = "",   // WireGuard client key assigned to this server
    var clientAddress: String = "",      // e.g. "10.8.0.2/32"
    var dns: String = "1.1.1.1",
    var allowedIps: String = "0.0.0.0/0",
    var isPremium: Boolean = false,      // gate behind rewarded ad if true
    var isEnabled: Boolean = true,       // admin can disable without deleting
    var load: Int = 0                    // 0-100, shown as a signal-strength style indicator
)
