package com.mbbs.vpnstudent

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.mbbs.vpnstudent.databinding.ItemServerBinding
import com.mbbs.vpnstudent.model.ServerConfig

class ServerAdapter(
    private val onClick: (ServerConfig) -> Unit
) : RecyclerView.Adapter<ServerAdapter.VH>() {

    private val items = mutableListOf<ServerConfig>()

    fun submitList(list: List<ServerConfig>) {
        items.clear()
        items.addAll(list.sortedBy { it.load })
        notifyDataSetChanged()
    }

    inner class VH(val binding: ItemServerBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemServerBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val server = items[position]
        holder.binding.serverName.text = server.name
        holder.binding.serverCountry.text = server.countryCode
        holder.binding.serverLoad.text = "${server.load}% load"
        holder.binding.premiumBadge.visibility =
            if (server.isPremium) android.view.View.VISIBLE else android.view.View.GONE
        holder.binding.root.setOnClickListener { onClick(server) }
    }

    override fun getItemCount() = items.size
}
