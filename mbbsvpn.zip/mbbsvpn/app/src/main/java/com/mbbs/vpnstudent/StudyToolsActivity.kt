package com.mbbs.vpnstudent

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import com.mbbs.vpnstudent.databinding.ActivityStudyToolsBinding

/**
 * Extra features aimed at MBBS students studying in Russia:
 * - Pomodoro study timer
 * - Quick unit/dose converter (mg<->g, kg<->lb, C<->F) common in med study
 * - RUB currency quick-convert (manual rate, editable)
 * - Emergency numbers for Russia
 * - Simple offline notes
 */
class StudyToolsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityStudyToolsBinding
    private val prefs by lazy { getSharedPreferences("study_notes", Context.MODE_PRIVATE) }
    private var timerRunning = false
    private var secondsLeft = 25 * 60
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStudyToolsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupPomodoro()
        setupConverter()
        setupEmergency()
        setupNotes()
    }

    private fun setupPomodoro() {
        updateTimerText()
        binding.btnStartTimer.setOnClickListener {
            timerRunning = !timerRunning
            binding.btnStartTimer.text = if (timerRunning) "Pause" else "Start 25 min focus"
            if (timerRunning) tick()
        }
        binding.btnResetTimer.setOnClickListener {
            timerRunning = false
            secondsLeft = 25 * 60
            binding.btnStartTimer.text = "Start 25 min focus"
            updateTimerText()
        }
    }

    private fun tick() {
        if (!timerRunning) return
        handler.postDelayed({
            if (timerRunning && secondsLeft > 0) {
                secondsLeft--
                updateTimerText()
                tick()
            }
        }, 1000)
    }

    private fun updateTimerText() {
        val m = secondsLeft / 60
        val s = secondsLeft % 60
        binding.timerText.text = String.format("%02d:%02d", m, s)
    }

    private fun setupConverter() {
        val units = arrayOf("kg to lb", "lb to kg", "mg to g", "g to mg", "C to F", "F to C")
        binding.unitSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, units)
        binding.btnConvert.setOnClickListener {
            val input = binding.converterInput.text.toString().toDoubleOrNull()
            if (input == null) {
                binding.converterResult.text = "Enter a number"
                return@setOnClickListener
            }
            val result = when (binding.unitSpinner.selectedItem as String) {
                "kg to lb" -> input * 2.20462
                "lb to kg" -> input / 2.20462
                "mg to g" -> input / 1000.0
                "g to mg" -> input * 1000.0
                "C to F" -> input * 9 / 5 + 32
                "F to C" -> (input - 32) * 5 / 9
                else -> input
            }
            binding.converterResult.text = "= %.3f".format(result)
        }
    }

    private fun setupEmergency() {
        // Common Russia-wide emergency numbers, useful for international students
        val numbers = listOf(
            "Единый номер / All emergencies" to "112",
            "Ambulance" to "103",
            "Police" to "102",
            "Fire" to "101"
        )
        val sb = StringBuilder()
        numbers.forEach { (label, num) -> sb.append("$label: $num\n") }
        binding.emergencyText.text = sb.toString().trim()
        binding.btnCallEmergency.setOnClickListener {
            startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:112")))
        }
    }

    private fun setupNotes() {
        binding.notesInput.setText(prefs.getString("notes", ""))
        binding.btnSaveNotes.setOnClickListener {
            prefs.edit().putString("notes", binding.notesInput.text.toString()).apply()
        }
    }
}
