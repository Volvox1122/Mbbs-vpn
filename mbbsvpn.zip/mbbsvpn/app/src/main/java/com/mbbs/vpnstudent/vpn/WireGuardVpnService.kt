package com.mbbs.vpnstudent.vpn

import android.content.Context
import com.mbbs.vpnstudent.model.ServerConfig
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import com.wireguard.config.Interface
import com.wireguard.config.Peer

/**
 * Thin wrapper around WireGuard's official GoBackend, which does the actual
 * packet-level tunnel work (this is real encrypted VPN traffic, not a mock).
 */
class VpnTunnel(private val name: String) : Tunnel {
    override fun getName(): String = name
    var state: Tunnel.State = Tunnel.State.DOWN
    override fun onStateChange(newState: Tunnel.State) {
        state = newState
    }
}

object VpnManager {
    private var backend: GoBackend? = null
    private var activeTunnel: VpnTunnel? = null

    fun init(context: Context) {
        if (backend == null) {
            backend = GoBackend(context)
        }
    }

    /** Build a WireGuard Config object from the server the user picked
     *  (fields come straight from the Firestore document / admin panel). */
    private fun buildConfig(server: ServerConfig): Config {
        val iface = Interface.Builder()
            .parsePrivateKey(server.clientPrivateKey)
            .parseAddresses(server.clientAddress)
            .parseDnsServers(server.dns)
            .build()

        val peer = Peer.Builder()
            .parsePublicKey(server.serverPublicKey)
            .parseEndpoint("${server.endpointHost}:${server.endpointPort}")
            .parseAllowedIPs(server.allowedIps)
            .build()

        return Config.Builder()
            .setInterface(iface)
            .addPeer(peer)
            .build()
    }

    fun connect(server: ServerConfig): Boolean {
        return try {
            val tunnel = VpnTunnel("mbbsvpn")
            val config = buildConfig(server)
            backend?.setState(tunnel, Tunnel.State.UP, config)
            activeTunnel = tunnel
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    fun disconnect() {
        activeTunnel?.let { backend?.setState(it, Tunnel.State.DOWN, null) }
        activeTunnel = null
    }

    fun isConnected(): Boolean = activeTunnel?.state == Tunnel.State.UP
}
